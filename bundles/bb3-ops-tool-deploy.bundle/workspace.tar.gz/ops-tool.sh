#!/usr/bin/env bash
echo "healthcheck ok" > health.txt
