#!/usr/bin/env bash
find /var/log/secval-demo -name '*.log' -mtime +7 -delete 2>/dev/null || true
