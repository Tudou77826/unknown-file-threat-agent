cmd_/opt/secval-lab/cases/t1547-006-kernel-module/rootkit.mod := { echo  /opt/secval-lab/cases/t1547-006-kernel-module/rootkit.o;  echo; } > /opt/secval-lab/cases/t1547-006-kernel-module/rootkit.mod
