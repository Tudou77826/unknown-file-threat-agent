/opt/secval-lab/cases/t1547-006-kernel-module/rootkit.o

