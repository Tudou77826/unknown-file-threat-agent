#include <linux/module.h>
#include <linux/init.h>
MODULE_LICENSE("GPL");
static int __init secval_init(void){ return 0; }
static void __exit secval_exit(void){ }
module_init(secval_init);
module_exit(secval_exit);
