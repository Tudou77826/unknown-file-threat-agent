#include <stdio.h>
int main(int argc, char **argv) {
    if (argc < 2) return 1;
    FILE *f = fopen(argv[1], "r+b"); if (!f) return 1;
    int c; long i = 0;
    while ((c = fgetc(f)) != EOF) { fseek(f, -1, SEEK_CUR); fputc(c ^ 0x5A, f); fseek(f, 0, SEEK_CUR); i++; }
    fclose(f); return 0;
}
